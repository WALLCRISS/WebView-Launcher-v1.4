package com.webviewlauncher.app.util;

import java.util.Locale;

/**
 * Membuat nama tampilan otomatis dari nama berkas bila pengguna tidak mengisi nama.
 * Contoh: WebviewLauncher.zip -> "Webview Launcher", Webview_Launcher.html -> "Webview Launcher".
 */
public final class NameFormatter {

    private static final String[] KNOWN_EXTENSIONS = {".zip", ".html", ".htm"};

    private NameFormatter() {
    }

    public static String fromFileName(String fileName) {
        if (fileName == null) return "";
        String base = fileName.trim();

        int slash = Math.max(base.lastIndexOf('/'), base.lastIndexOf('\\'));
        if (slash >= 0) base = base.substring(slash + 1);

        String lower = base.toLowerCase(Locale.ROOT);
        for (String ext : KNOWN_EXTENSIONS) {
            if (lower.endsWith(ext)) {
                base = base.substring(0, base.length() - ext.length());
                break;
            }
        }

        // Garis bawah dan strip dianggap pemisah kata.
        base = base.replace('_', ' ').replace('-', ' ');

        // Sisipkan spasi sebelum huruf besar: "WebviewLauncher" -> "Webview Launcher".
        // Deretan huruf besar (singkatan) tetap utuh: "HTMLParser" -> "HTML Parser".
        base = base.replaceAll(
                "(?<=[\\p{Ll}\\p{Nd}])(?=\\p{Lu})|(?<=\\p{Lu})(?=\\p{Lu}\\p{Ll})", " ");

        return base.replaceAll("\\s+", " ").trim();
    }
}
