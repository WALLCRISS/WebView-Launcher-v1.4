package com.webviewlauncher.app.model;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Merepresentasikan satu game yang telah ditambahkan pengguna.
 * entryFilePath menunjuk ke berkas .html utama di dalam folder yang sudah diekstrak,
 * sehingga game dengan banyak file dan folder (seperti SpaceStrike) tetap bisa
 * memuat seluruh asetnya secara relatif melalui file://.
 */
public class GameItem {

    public String id;
    public String title;
    public String iconPath;
    public String entryFilePath;

    /** Nama berkas asli seperti dipilih pengguna, mis. "WebViewLauncher.zip". */
    public String originalFileName = "";
    /** Lokasi berkas asli yang bisa dibaca manusia, mis. "Download/WebViewLauncher/WebViewLauncher.zip". */
    public String sourcePath = "";
    /** Ukuran berkas asli dalam byte, -1 bila tidak diketahui (mis. item lama sebelum fitur ini ada). */
    public long fileSizeBytes = -1;
    /** Waktu item ditambahkan (System.currentTimeMillis()), 0 bila tidak diketahui. */
    public long dateAddedMillis = 0;
    /** "zip" atau "html". */
    public String fileType = "";

    public GameItem() {
    }

    public GameItem(String id, String title, String iconPath, String entryFilePath) {
        this.id = id;
        this.title = title;
        this.iconPath = iconPath;
        this.entryFilePath = entryFilePath;
    }

    public GameItem(String id, String title, String iconPath, String entryFilePath,
                     String originalFileName, String sourcePath, long fileSizeBytes,
                     long dateAddedMillis, String fileType) {
        this.id = id;
        this.title = title;
        this.iconPath = iconPath;
        this.entryFilePath = entryFilePath;
        this.originalFileName = originalFileName == null ? "" : originalFileName;
        this.sourcePath = sourcePath == null ? "" : sourcePath;
        this.fileSizeBytes = fileSizeBytes;
        this.dateAddedMillis = dateAddedMillis;
        this.fileType = fileType == null ? "" : fileType;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("iconPath", iconPath);
        o.put("entryFilePath", entryFilePath);
        o.put("originalFileName", originalFileName);
        o.put("sourcePath", sourcePath);
        o.put("fileSizeBytes", fileSizeBytes);
        o.put("dateAddedMillis", dateAddedMillis);
        o.put("fileType", fileType);
        return o;
    }

    public static GameItem fromJson(JSONObject o) throws JSONException {
        return new GameItem(
                o.getString("id"),
                o.getString("title"),
                o.optString("iconPath", ""),
                o.getString("entryFilePath"),
                o.optString("originalFileName", ""),
                o.optString("sourcePath", ""),
                o.optLong("fileSizeBytes", -1),
                o.optLong("dateAddedMillis", 0),
                o.optString("fileType", "")
        );
    }
}
