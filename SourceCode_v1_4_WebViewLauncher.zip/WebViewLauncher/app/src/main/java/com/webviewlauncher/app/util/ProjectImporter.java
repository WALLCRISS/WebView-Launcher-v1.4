package com.webviewlauncher.app.util;

import android.content.Context;
import android.graphics.Bitmap;

import com.webviewlauncher.app.data.DataStore;
import com.webviewlauncher.app.model.GameItem;

import java.io.File;
import java.io.InputStream;
import java.util.List;

/**
 * Logika untuk memasukkan satu proyek HTML ke daftar (berkas dipilih di layar Tambah).
 *
 * Ikon dipilih dengan urutan: gambar pilihan pengguna -> gambar icon.png/icon.jpg di dalam
 * .zip (dibuat persegi dan sudutnya dihaluskan) -> ikon otomatis (oranye HTML / hijau .zip).
 * Bila nama kosong, nama dibuat dari nama berkas (lihat {@link NameFormatter}).
 */
public final class ProjectImporter {

    /** Tidak ada berkas .html di dalam proyek. */
    public static class EntryNotFoundException extends Exception {
    }

    private ProjectImporter() {
    }

    /**
     * @param data       isi berkas .zip atau .html
     * @param isZip      true bila data adalah .zip
     * @param fileName   nama berkas asli (untuk nama otomatis)
     * @param userTitle  nama dari pengguna; boleh kosong
     * @param manualIcon gambar ikon pilihan pengguna; boleh null
     * @param sourcePath lokasi berkas asli yang mudah dibaca manusia (untuk layar info berkas); boleh kosong
     * @param fileSizeBytes ukuran berkas asli dalam byte; -1 bila tidak diketahui
     * @return item yang sudah tersimpan di daftar
     */
    public static GameItem importProject(Context context, InputStream data, boolean isZip,
                                         String fileName, String userTitle, InputStream manualIcon,
                                         long maxExtractBytes, String sourcePath, long fileSizeBytes) throws Exception {
        String id = FileUtils.randomId();
        File gameDir = new File(context.getFilesDir(), "games/" + id);
        File iconFile = new File(new File(context.getFilesDir(), "icons"), id + ".png");
        boolean success = false;

        try {
            gameDir.mkdirs();

            File entryFile;
            if (isZip) {
                ZipExtractor.extract(data, gameDir, maxExtractBytes);
                entryFile = ZipExtractor.findEntryHtml(gameDir);
            } else {
                entryFile = new File(gameDir, "index.html");
                FileUtils.copyStreamToFile(data, entryFile);
            }
            if (entryFile == null || !entryFile.exists()) {
                throw new EntryNotFoundException();
            }

            boolean iconDone = false;
            if (manualIcon != null) {
                FileUtils.copyStreamToFile(manualIcon, iconFile);
                iconDone = true;
            } else if (isZip) {
                Bitmap embedded = IconUtils.fromFile(ZipExtractor.findIconFile(gameDir), IconUtils.ICON_SIZE);
                if (embedded != null) {
                    IconUtils.savePng(embedded, iconFile);
                    iconDone = true;
                }
            }
            if (!iconDone) {
                Bitmap generated = DocumentIconGenerator.generate(isZip ? "zip" : "html", 200);
                IconUtils.savePng(generated, iconFile);
            }

            String title = userTitle == null ? "" : userTitle.trim();
            if (title.isEmpty()) title = NameFormatter.fromFileName(fileName);
            if (title.isEmpty()) title = "HTML";

            GameItem item = new GameItem(id, title, iconFile.getAbsolutePath(), entryFile.getAbsolutePath(),
                    fileName == null ? "" : fileName,
                    sourcePath == null ? "" : sourcePath,
                    fileSizeBytes,
                    System.currentTimeMillis(),
                    isZip ? "zip" : "html");
            DataStore dataStore = new DataStore(context);
            List<GameItem> games = dataStore.loadGames();
            games.add(item);
            dataStore.saveGames(games);

            success = true;
            return item;
        } finally {
            if (!success) {
                FileUtils.deleteRecursive(gameDir);
                FileUtils.deleteRecursive(iconFile);
            }
        }
    }
}
