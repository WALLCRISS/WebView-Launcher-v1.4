package com.webviewlauncher.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;

import com.webviewlauncher.app.util.DocumentIconGenerator;
import com.webviewlauncher.app.util.FileUtils;
import com.webviewlauncher.app.util.IconUtils;
import com.webviewlauncher.app.util.NameFormatter;
import com.webviewlauncher.app.util.ProjectImporter;
import com.webviewlauncher.app.util.ZipExtractor;

import java.io.InputStream;
import java.util.Locale;

public class AddGameActivity extends AppCompatActivity {

    private ImageView iconPreview;
    private TextView fileNameText;
    private EditText nameInput;
    private ProgressBar progressBar;
    private Button saveButton;
    private Button pickFileButton;
    private Button pickIconButton;

    private Uri selectedFileUri;
    private Uri selectedIconUri;
    private String selectedFileName = "";
    private String selectedSourcePath = "";
    private long selectedFileSize = -1;
    private int previewToken = 0;

    private final ActivityResultLauncher<String[]> pickFileLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri == null) return;
                selectedFileUri = uri;
                selectedFileName = queryDisplayName(uri);
                selectedSourcePath = FileUtils.guessDisplayPath(this, uri, selectedFileName);
                selectedFileSize = FileUtils.querySizeFromUri(this, uri);
                fileNameText.setText(selectedFileName + "\n"
                        + getString(R.string.auto_name_label, NameFormatter.fromFileName(selectedFileName)));
                refreshAutoIconPreview();
            }
    );

    private final ActivityResultLauncher<String[]> pickIconLauncher = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),
            uri -> {
                if (uri == null) return;
                selectedIconUri = uri;
                previewToken++;
                try (InputStream is = getContentResolver().openInputStream(uri)) {
                    Bitmap bmp = BitmapFactory.decodeStream(is);
                    if (bmp != null) iconPreview.setImageBitmap(bmp);
                } catch (Exception ignored) {
                }
            }
    );

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_game);

        iconPreview = findViewById(R.id.iconPreview);
        fileNameText = findViewById(R.id.fileNameText);
        nameInput = findViewById(R.id.nameInput);
        progressBar = findViewById(R.id.progressBar);
        saveButton = findViewById(R.id.saveButton);
        pickFileButton = findViewById(R.id.pickFileButton);
        pickIconButton = findViewById(R.id.pickIconButton);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        pickIconButton.setOnClickListener(v -> pickIconLauncher.launch(new String[]{"image/*"}));
        pickFileButton.setOnClickListener(v -> pickFileLauncher.launch(new String[]{"*/*"}));

        saveButton.setOnClickListener(v -> onSaveClicked());
    }

    /**
     * Pratinjau ikon yang akan dipakai bila pengguna tidak memilih gambar sendiri:
     * icon.png / icon.jpg dari dalam .zip bila ada, selain itu ikon otomatis oranye (HTML) / hijau (.zip).
     */
    private void refreshAutoIconPreview() {
        if (selectedIconUri != null) return;

        final boolean isZip = isZipName(selectedFileName);
        iconPreview.setImageBitmap(DocumentIconGenerator.generate(isZip ? "zip" : "html", 200));
        if (!isZip || selectedFileUri == null) return;

        final int token = ++previewToken;
        final Uri uri = selectedFileUri;
        new Thread(() -> {
            Bitmap embedded = null;
            try (InputStream is = getContentResolver().openInputStream(uri)) {
                if (is != null) {
                    embedded = IconUtils.fromBytes(ZipExtractor.peekIcon(is), IconUtils.ICON_SIZE);
                }
            } catch (Exception ignored) {
            }
            final Bitmap result = embedded;
            if (result == null) return;
            runOnUiThread(() -> {
                if (token == previewToken && selectedIconUri == null) {
                    iconPreview.setImageBitmap(result);
                }
            });
        }).start();
    }

    private void onSaveClicked() {
        if (selectedFileUri == null) {
            Toast.makeText(this, R.string.error_pick_file, Toast.LENGTH_SHORT).show();
            return;
        }

        // Nama boleh kosong: ProjectImporter membuatnya dari nama berkas.
        final String name = nameInput.getText().toString().trim();
        final Uri fileUri = selectedFileUri;
        final Uri iconUri = selectedIconUri;
        final String fileName = selectedFileName;
        final String sourcePath = selectedSourcePath;
        final long fileSize = selectedFileSize;
        final boolean isZip = isZipName(fileName);

        setLoading(true);

        new Thread(() -> {
            try (InputStream data = getContentResolver().openInputStream(fileUri);
                 InputStream icon = iconUri != null ? getContentResolver().openInputStream(iconUri) : null) {
                if (data == null) throw new java.io.IOException("Tidak bisa membuka berkas");
                ProjectImporter.importProject(getApplicationContext(), data, isZip, fileName, name, icon,
                        Long.MAX_VALUE, sourcePath, fileSize);
                runOnUiThread(() -> {
                    setResult(Activity.RESULT_OK);
                    finish();
                });
            } catch (ProjectImporter.EntryNotFoundException e) {
                runOnUiThread(() -> {
                    setLoading(false);
                    Toast.makeText(this, R.string.error_entry_not_found, Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setLoading(false);
                    Toast.makeText(this, R.string.error_extract, Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private static boolean isZipName(String fileName) {
        return fileName != null && fileName.toLowerCase(Locale.ROOT).endsWith(".zip");
    }

    private void setLoading(boolean loading) {
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        saveButton.setEnabled(!loading);
        pickFileButton.setEnabled(!loading);
        pickIconButton.setEnabled(!loading);
    }

    private String queryDisplayName(Uri uri) {
        String result = "";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) result = cursor.getString(idx);
            }
        } catch (Exception ignored) {
        }
        if (result == null || result.isEmpty()) {
            result = uri.getLastPathSegment();
        }
        return result == null ? "" : result;
    }
}
