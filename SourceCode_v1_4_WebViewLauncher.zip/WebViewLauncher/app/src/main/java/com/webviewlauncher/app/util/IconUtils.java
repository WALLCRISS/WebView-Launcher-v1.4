package com.webviewlauncher.app.util;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Menyiapkan ikon dari gambar (misalnya icon.png / icon.jpg di dalam .zip):
 * dipotong persegi dari tengah, lalu bila gambarnya masih kotak dengan sudut tajam
 * sudutnya dibulatkan sedikit supaya terlihat halus dan tidak kaku.
 * Gambar yang sudutnya sudah transparan (sudah berbentuk sendiri) dibiarkan apa adanya.
 */
public final class IconUtils {

    public static final int ICON_SIZE = 256;

    /** Sama dengan lengkungan ikon otomatis di DocumentIconGenerator. */
    private static final float CORNER_RATIO = 0.18f;

    private static final long MAX_ICON_BYTES = 8L * 1024 * 1024;

    private IconUtils() {
    }

    public static Bitmap fromFile(File file, int size) {
        if (file == null || !file.isFile() || file.length() > MAX_ICON_BYTES) return null;
        try {
            return fromBytes(FileUtils.readAllBytes(file), size);
        } catch (IOException e) {
            return null;
        }
    }

    /** @return ikon siap pakai berukuran size x size, atau null bila bukan gambar valid. */
    public static Bitmap fromBytes(byte[] data, int size) {
        if (data == null || data.length == 0) return null;
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

            int sample = 1;
            int minSide = Math.min(bounds.outWidth, bounds.outHeight);
            while (minSide / (sample * 2) >= size) sample *= 2;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            Bitmap src = BitmapFactory.decodeByteArray(data, 0, data.length, opts);
            if (src == null) return null;

            int side = Math.min(src.getWidth(), src.getHeight());
            int left = (src.getWidth() - side) / 2;
            int top = (src.getHeight() - side) / 2;

            Bitmap square = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(square);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            canvas.drawBitmap(src, new Rect(left, top, left + side, top + side),
                    new Rect(0, 0, size, size), paint);
            src.recycle();

            if (!hasOpaqueCorners(square)) return square;
            return roundCorners(square, size * CORNER_RATIO);
        } catch (Throwable t) {
            return null;
        }
    }

    public static void savePng(Bitmap bitmap, File dest) throws IOException {
        File parent = dest.getParentFile();
        if (parent != null && !parent.exists()) parent.mkdirs();
        try (FileOutputStream fos = new FileOutputStream(dest)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
        }
    }

    private static boolean hasOpaqueCorners(Bitmap bmp) {
        int last = bmp.getWidth() - 1;
        int[][] points = {{0, 0}, {last, 0}, {0, last}, {last, last}};
        for (int[] p : points) {
            if (Color.alpha(bmp.getPixel(p[0], p[1])) < 250) return false;
        }
        return true;
    }

    private static Bitmap roundCorners(Bitmap square, float radius) {
        int size = square.getWidth();
        Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        canvas.drawRoundRect(new RectF(0, 0, size, size), radius, radius, paint);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(square, 0, 0, paint);
        square.recycle();
        return out;
    }
}
