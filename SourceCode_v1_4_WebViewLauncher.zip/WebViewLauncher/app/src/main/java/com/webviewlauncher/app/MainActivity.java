package com.webviewlauncher.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.webviewlauncher.app.data.DataStore;

/**
 * Layar utama: header dan daftar proyek HTML (GameFragment).
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Fitur PDF sudah dihapus: bersihkan sisa data lama bila aplikasi diperbarui.
        new DataStore(this).purgeLegacyDocuments();
    }
}
