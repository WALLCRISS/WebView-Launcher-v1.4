# WebView Launcher  (versi 1.4)

Aplikasi Android native (Java murni, 100% offline, tanpa izin apa pun) untuk menjalankan proyek
HTML lokal.

## Fitur

- **Pembaca HTML**: tambahkan `.zip` (berisi html/css/js dan file/folder pendukung lain,
  diekstrak otomatis, mencari `index.html`) atau file `.html` tunggal. Dibuka lewat WebView
  layar penuh dengan dukungan modul JavaScript dan fetch(). Tombol kembali menyusut jadi
  garis kecil di atas layar setelah 1.5 detik tak disentuh (ketuk garisnya untuk memunculkan
  lagi).
- **Ikon otomatis** (bila tidak memilih gambar ikon saat menambah):
  - `.zip` yang berisi gambar bernama `icon.png` / `icon.jpg` (juga `.jpeg`, `.webp`) memakai
    gambar itu. Yang paling dekat dengan akar zip diutamakan. Gambar dipotong persegi dari
    tengah, dan bila masih kotak bersudut tajam, sudutnya dibulatkan sedikit agar halus.
    Gambar yang sudutnya sudah transparan dibiarkan apa adanya.
  - Tidak ada icon di dalam zip: ikon oranye (HTML) atau hijau (.zip) seperti sebelumnya.
- **Nama otomatis** (bila kolom nama kosong): diambil dari nama berkas, dengan spasi di setiap
  huruf besar dan garis bawah/strip jadi spasi.
  `WebviewLauncher.zip` → `Webview Launcher`, `Webview_Launcher.html` → `Webview Launcher`.
  Singkatan tetap utuh (`HTMLParser` → `HTML Parser`).
- **Splash screen** memakai logo tanpa background (`res/drawable-nodpi/splash_logo.png`) di atas
  latar `#202835`, warna yang sama dengan latar ikon aplikasi. (Android 12+ menampilkan splash
  bawaan sistem dengan ikon aplikasi sepersekian detik sebelum splash ini; itu perilaku sistem.)
- **Ikon adaptif** (Android 8+): foto ikon yang sama di atas latar `#202835`, supaya splash bawaan
  Android 12+ tidak lagi menampilkan kotak putih di belakang ikon. Android 7 ke bawah memakai
  `ic_launcher.jpg` seperti biasa.
- **Tekan lama** pada item di grid: muncul pilihan bergambar **tanda seru** (info berkas) dan
  **tempat sampah** (hapus).
- **Info berkas**: menampilkan nama tampilan, nama berkas asli, lokasi folder asal berkas
  (mis. `Download/WebViewLauncher/WebViewLauncher.zip`), ukuran, jenis (.zip/.html), dan kapan
  berkas ditambahkan. Untuk item yang ditambahkan sebelum fitur ini ada, kolom yang tidak
  tersimpan ditampilkan sebagai "Tidak diketahui".
- Tema warna ungu-toska gelap, seluruh ikon berupa gambar vector buatan sendiri.

Fitur PDF reader dari versi 1.0 sudah dihapus. Sisa daftar PDF lama dibersihkan otomatis saat
aplikasi diperbarui.

## Cara build APK

Proyek Android Studio standar (Gradle, Java).

1. Buka **Android Studio** → `Open` → pilih folder `WebViewLauncher`.
2. Tunggu Gradle sync selesai (butuh internet pertama kali untuk mengunduh dependensi AndroidX).
3. `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`.
4. APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

Alternatif: `./gradlew assembleDebug` (jalankan `gradle wrapper` dulu bila `gradlew` belum ada),
atau import folder ini di aplikasi IDE Android seperti CodeAssist.

## Struktur singkat kode

- `SplashActivity` — splash screen, lalu membuka `MainActivity`
- `MainActivity` — header + `GameFragment`
- `GameFragment` — grid proyek HTML, dialog hapus
- `AddGameActivity` — tambah proyek (ikon & nama otomatis)
- `WebGameActivity` — WebView layar penuh, navigasi collapse lewat `widget/CollapsibleNav`
- `util/ProjectImporter` — logika memasukkan proyek ke daftar
- `util/ZipExtractor` — ekstraksi zip, cari `index.html` dan `icon.*`
- `util/IconUtils`, `util/DocumentIconGenerator`, `util/NameFormatter` — ikon dan nama otomatis
- `data/DataStore` — penyimpanan daftar ke JSON lokal
